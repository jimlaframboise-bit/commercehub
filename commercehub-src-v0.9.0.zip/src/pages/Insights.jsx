import { useState } from 'react'
import { Kpi, KpiGrid, Card, Pill, Btn, SearchBox, DataGrid, FilterBar, applyFilters, loadFilterModel, ExportMenu } from '../components/ui.jsx'
import Icon from '../components/Icon.jsx'
import { reports, reportTemplates, alerts as ALERTS } from '../data/mock.js'

function InsHead({ title, sub, children }) {
  return <div className="page-head"><div><div className="page-title">{title}</div><div className="page-sub">{sub}</div></div><div className="page-actions">{children}</div></div>
}

/* ============================ REPORT CENTER ============================ */
const RP_TYPES = ['Dashboard', 'Campaign', 'Search Term', 'Share of Voice', 'Commerce', 'DSP']
const RP_FORMATS = ['PDF', 'XLSX', 'CSV', 'PDF + XLSX']
const RP_OWNERS = ['You', 'A. Rivera', 'M. Chen']
const RP_FIELDS = [
  { key: 'name', label: 'Report', type: 'text' },
  { key: 'type', label: 'Type', type: 'enum', options: RP_TYPES },
  { key: 'cadence', label: 'Schedule', type: 'text' },
  { key: 'format', label: 'Format', type: 'enum', options: RP_FORMATS },
  { key: 'recipients', label: 'Recipients', type: 'number' },
  { key: 'owner', label: 'Owner', type: 'enum', options: RP_OWNERS },
  { key: 'updated', label: 'Updated', type: 'text' },
]
export function Reports() {
  const [q, setQ] = useState('')
  const [filters, setFilters] = useState(() => loadFilterModel('ins-reports'))
  const searched = reports.filter((r) => r.name.toLowerCase().includes(q.toLowerCase()) || r.type.toLowerCase().includes(q.toLowerCase()))
  const filtered = applyFilters(searched, filters, RP_FIELDS)
  const columns = [
    { key: 'name', label: 'Report', sticky: true, width: 300, sortVal: (r) => r.name, render: (r) => <div>{r.name}<small>{r.type}</small></div> },
    { key: 'cadence', label: 'Schedule', sortVal: (r) => r.cadence, render: (r) => <span className="tag">{r.cadence}</span> },
    { key: 'format', label: 'Format', sortVal: (r) => r.format },
    { key: 'recipients', label: 'Recipients', num: true, foot: (rs) => rs.reduce((s, r) => s + r.recipients, 0), render: (r) => `${r.recipients}` },
    { key: 'owner', label: 'Owner', sortVal: (r) => r.owner },
    { key: 'updated', label: 'Updated', sortVal: (r) => r.updated, render: (r) => <span className="muted">{r.updated}</span> },
    { key: 'act', label: '', sort: false, render: () => <span style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}><Btn sm ghost icon="play">Run</Btn><Btn sm ghost icon="download" /></span> },
  ]
  const dims = [{ key: 'type', label: 'Type' }, { key: 'owner', label: 'Owner' }, { key: 'format', label: 'Format' }]
  return (
    <>
      <InsHead title="Report Center" sub="Custom & scheduled reports, dashboards and exports"><ExportMenu name="report-center" fields={RP_FIELDS} rows={filtered} /><Btn icon="file" ghost>Templates</Btn><Btn icon="plus" primary>Build Report</Btn></InsHead>
      <KpiGrid>
        <Kpi label="Saved Reports" value={reports.length} />
        <Kpi label="Scheduled" value={reports.filter(r => /·/.test(r.cadence)).length} />
        <Kpi label="Recipients" value={reports.reduce((s, r) => s + r.recipients, 0)} />
        <Kpi label="Widgets Available" value={reportTemplates.length} />
      </KpiGrid>
      <Card title="Report builder — data sources" sub="Drag widgets onto a custom dashboard" >
        <div className="grid-3">
          {reportTemplates.map((t) => (
            <div key={t} className="lrow" style={{ border: '1px solid var(--border)', borderRadius: 10, padding: 11 }}>
              <div className="icobox" style={{ background: 'var(--brand-soft)', color: 'var(--brand)' }}><Icon name="bars" size={16} /></div>
              <div className="grow"><div className="title" style={{ fontSize: 12.5 }}>{t}</div></div>
              <Icon name="plus" size={15} className="muted" />
            </div>
          ))}
        </div>
      </Card>
      <div style={{ height: 16 }} />
      <DataGrid
        id="ins-reports"
        columns={columns}
        rows={filtered}
        initialSort={{ key: 'name', dir: 'asc' }}
        dimensions={dims}
        totals
        toolbarLeft={<>
          <SearchBox value={q} onChange={setQ} placeholder="Search reports…" />
          <FilterBar id="ins-reports" fields={RP_FIELDS} value={filters} onChange={setFilters} />
        </>}
      />
      <div className="footnote">Filter saved & scheduled reports, group by type or owner, and export the current list. Build new reports from the data-source widgets above.</div>
    </>
  )
}

/* ============================ ALERTS ============================ */
const sevTone = { high: 'red', med: 'amber', low: 'gray' }
const AL_FIELDS = [
  { key: 'title', label: 'Alert', type: 'text' },
  { key: 'body', label: 'Detail', type: 'text' },
  { key: 'sevLabel', label: 'Severity', type: 'enum', options: ['High', 'Med', 'Low'] },
  { key: 'status', label: 'Status', type: 'enum', options: ['Unread', 'Read'] },
  { key: 'time', label: 'Time', type: 'text' },
]
const sevRank = { high: 3, med: 2, low: 1 }
export function Alerts() {
  const [alerts, setAlerts] = useState(ALERTS)
  const [q, setQ] = useState('')
  const [filters, setFilters] = useState(() => loadFilterModel('ins-alerts'))
  const markRead = (id) => setAlerts((a) => a.map((x) => x.id === id ? { ...x, read: true } : x))
  const markAll = () => setAlerts((a) => a.map((x) => ({ ...x, read: true })))
  const decorated = alerts.map((a) => ({ ...a, sevLabel: { high: 'High', med: 'Med', low: 'Low' }[a.sev], status: a.read ? 'Read' : 'Unread' }))
  const searched = decorated.filter((a) => a.title.toLowerCase().includes(q.toLowerCase()) || a.body.toLowerCase().includes(q.toLowerCase()))
  const filtered = applyFilters(searched, filters, AL_FIELDS)
  const columns = [
    { key: 'title', label: 'Alert', sticky: true, width: 360, sortVal: (r) => r.title, render: (a) => (
      <div className="flex items-center gap-8">
        <div className="icobox" style={{ background: insSevBg(a.sev), color: insSevColor(a.sev), width: 30, height: 30, flex: '0 0 auto' }}><Icon name={a.icon} size={15} /></div>
        <div><div className="title" style={{ fontWeight: a.read ? 600 : 750 }}>{a.title}{!a.read && <span className="dot-unread" />}</div><small>{a.body}</small></div>
      </div>
    ) },
    { key: 'sevLabel', label: 'Severity', sortVal: (r) => sevRank[r.sev], render: (a) => <Pill tone={sevTone[a.sev]}>{a.sevLabel}</Pill> },
    { key: 'status', label: 'Status', sortVal: (r) => r.status, render: (a) => a.read ? <span className="muted">Read</span> : <Pill tone="blue">Unread</Pill> },
    { key: 'time', label: 'Time', sortVal: (r) => r.time, render: (a) => <span className="muted">{a.time}</span> },
    { key: 'act', label: '', sort: false, render: (a) => !a.read ? <Btn sm ghost icon="check" onClick={() => markRead(a.id)}>Mark read</Btn> : <span className="muted" style={{ fontSize: 11 }}>—</span> },
  ]
  const dims = [{ key: 'sevLabel', label: 'Severity' }, { key: 'status', label: 'Status' }]
  return (
    <>
      <InsHead title="Alerts" sub="Real-time notifications across ads, budget & retail signals"><ExportMenu name="alerts" fields={AL_FIELDS} rows={filtered} /><Btn icon="check" ghost onClick={markAll}>Mark all read</Btn><Btn icon="gear" primary>Alert Settings</Btn></InsHead>
      <KpiGrid>
        <Kpi label="Unread" value={alerts.filter(a => !a.read).length} />
        <Kpi label="High Severity" value={alerts.filter(a => a.sev === 'high').length} />
        <Kpi label="Today" value={alerts.length} />
      </KpiGrid>
      <DataGrid
        id="ins-alerts"
        columns={columns}
        rows={filtered}
        initialSort={{ key: 'sevLabel', dir: 'desc' }}
        dimensions={dims}
        toolbarLeft={<>
          <SearchBox value={q} onChange={setQ} placeholder="Search alerts…" />
          <FilterBar id="ins-alerts" fields={AL_FIELDS} value={filters} onChange={setFilters} />
        </>}
      />
      <div className="footnote">Filter by severity or read status, sort by time, and export. High-severity retail signals (out-of-stock, Buy Box loss) trigger ad auto-pause via the rule engine.</div>
    </>
  )
}
const insSevBg = (s) => ({ high: 'var(--red-soft)', med: 'var(--amber-soft)', low: '#eef1f6' }[s])
const insSevColor = (s) => ({ high: 'var(--red)', med: 'var(--amber)', low: 'var(--text-2)' }[s])

/* ============================ SETTINGS ============================ */
export function Settings() {
  const conns = [
    { name: 'Amazon Ads API', detail: 'SP · SB · SD · profiles US / CA / UK', status: 'Connected', icon: 'ads' },
    { name: 'Amazon DSP', detail: 'Seat: Brightleaf Media', status: 'Connected', icon: 'globe' },
    { name: 'Amazon Marketing Cloud', detail: 'Instance: brightleaf-amc', status: 'Connected', icon: 'database' },
    { name: 'Selling Partner API (SP-API)', detail: 'Vendor Central · Seller Central', status: 'Connected', icon: 'store' },
    { name: 'Walmart Connect', detail: 'Not linked', status: 'Disconnected', icon: 'box' },
  ]
  return (
    <>
      <InsHead title="Settings" sub="Integrations, users & account configuration"><Btn icon="plus" primary>Add Integration</Btn></InsHead>
      <div className="grid-2">
        <Card title="Connected data sources" sub="Advertising & retail integrations" pad={false}>
          {conns.map((c) => (
            <div key={c.name} className="lrow">
              <div className="icobox" style={{ background: 'var(--surface-2)', color: 'var(--text-2)' }}><Icon name={c.icon} size={17} /></div>
              <div className="grow"><div className="title">{c.name}</div><div className="desc">{c.detail}</div></div>
              <Pill tone={c.status === 'Connected' ? 'green' : 'gray'}>{c.status}</Pill>
            </div>
          ))}
        </Card>
        <div style={{ display: 'grid', gap: 16, alignContent: 'start' }}>
          <Card title="Account" sub="Organization profile">
            <Field label="Organization" value="Brightleaf Media (Agency)" />
            <Field label="Default currency" value="USD ($)" />
            <Field label="Account time zone" value="America/Toronto" />
            <Field label="Plan" value="Enterprise · 3 marketplaces" />
          </Card>
          <Card title="Team" sub="4 members">
            {[['JL', 'Jim Laframboise', 'Owner'], ['AR', 'A. Rivera', 'Analyst'], ['MC', 'M. Chen', 'Manager']].map(([i, n, role]) => (
              <div key={n} className="lrow" style={{ padding: '9px 0' }}>
                <div className="avatar" style={{ background: 'var(--brand)' }}>{i}</div>
                <div className="grow"><div className="title" style={{ fontSize: 12.5 }}>{n}</div></div>
                <span className="tag">{role}</span>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </>
  )
}
function Field({ label, value }) {
  return <div className="flex between" style={{ padding: '9px 0', borderBottom: '1px solid var(--border)' }}>
    <span className="muted">{label}</span><b style={{ fontSize: 12.5 }}>{value}</b>
  </div>
}
