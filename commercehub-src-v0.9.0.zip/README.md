# CommerceHub — Retail Media Management Platform

A working prototype of a Pacvue-style retail-media command center for Amazon, covering
**Sponsored Ads**, **DSP**, and **Commerce / Digital Shelf** in one interface. Built as a
real React foundation you can extend toward a production product. All data is fictional
mock data generated locally — no live Amazon API and no real account data.

The information architecture (three modules, their sub-views, the metric vocabulary, and
the campaign-table columns) was modeled on the live Pacvue Amazon platform and Pacvue's
public documentation. See `FEATURE-MAP.md` for the full feature-by-feature mapping and sources.

## Run it

```bash
npm install
npm run dev
```

Then open the URL Vite prints (default http://localhost:5173). Build for production with
`npm run build` and preview with `npm run preview`.

Requirements: Node 18+ (developed on Node 22).

## Tech

- **React 18** + **Vite 5** (fast dev server, single-bundle build)
- **react-router-dom** (hash routing) for the module/view navigation
- **Recharts** for the trend/bar/share visualizations
- Hand-written CSS design system (`src/styles.css`) — no UI framework, easy to restyle

## Structure

```
src/
  main.jsx              app entry (HashRouter)
  App.jsx               routes → pages
  state.jsx             global context (selected profile + date range)
  styles.css            design system (colors, layout, tables, pills, toggles…)
  lib/format.js         number / currency / percent formatters
  data/mock.js          deterministic mock-data engine (all entities)
  components/
    Icon.jsx            inline SVG icon set
    Layout.jsx          sidebar nav + topbar (profile / date / filter / alerts)
    ui.jsx              KPI cards, DataTable (+ sorting), charts, buttons, pills, toggles
  pages/
    Overview.jsx        cross-channel executive dashboard
    Ads.jsx             Campaigns, Ad Groups, Targeting, Search Terms, Share of Voice, Dayparting
    Dsp.jsx             DSP Campaigns, Audience Builder, AMC
    Commerce.jsx        Digital Shelf, Buy Box & Inventory, Product Center
    Automation.jsx      Rule Manager, Budget Manager
    Insights.jsx        Report Center, Alerts, Settings
```

## What works in the prototype

- Profile switcher (All / US / CA / UK) and date-range control in the top bar filter the data.
- Campaign manager: sortable columns, type filters, search, **row enable/pause toggles**, and a
  **bulk-action bar** (enable, pause, adjust bids/budget, dayparting, apply rule, tag).
- Search-term **harvesting** workflow (harvest / negate / monitor recommendations).
- Dayparting **heatmap** of 7×24 hourly bid multipliers.
- Rule Manager with toggleable automation rules; Budget Manager with pacing bars.
- Digital Shelf / Buy Box monitoring with retail-signal → ad-action linkage (auto-pause).
- DSP orders, Audience Builder (seeds, templates, SP×DSP overlap), and AMC query library.

Interactions are local-state only (no persistence). This is a UI/UX and architecture
foundation; wiring real Amazon Ads / SP-API / DSP / AMC data is the next phase.

## Roadmap toward production

1. Replace `data/mock.js` with an API layer (Amazon Ads API, SP-API, DSP, AMC).
2. Add auth, multi-tenant accounts, and server-side rule execution.
3. Persist bid/budget/rule edits and add an approvals/audit trail.
4. Real scheduled Report Builder + export pipeline.
